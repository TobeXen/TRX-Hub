﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TRX_Hub
{
    public partial class Settings : Form
    {
        public Settings()
        {
            InitializeComponent();
        }
        Point lastPoint;
        private static Settings instance;

        private void Settings_Load(object sender, EventArgs e)
        {

        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Settings.instance = this;
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            _ = System.Diagnostics.Process.Start("https://discord.gg/VkyYHWBYsf");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            _ = System.Diagnostics.Process.Start("https://trx-executor.myfreesites.net/versions");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Process[] roblox = Process.GetProcesses();
            foreach (Process openedroblox in roblox)
            {
                bool flag = openedroblox.ProcessName == "RobloxPlayerBeta";
                if (flag)
                {
                    openedroblox.Kill();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            _ = System.Diagnostics.Process.Start("https://cdn.krnl.ca/getkey.php");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TRX_Executor_APEX frm = new TRX_Executor_APEX();
            frm.TopMost = true;
            frm.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Process.Start("rbxfpsunlocker");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Process[] FpsUnlock = Process.GetProcesses();
            foreach (Process openedFpsUnlock in FpsUnlock)
            {
                bool flag = openedFpsUnlock.ProcessName == "rbxfpsunlocker";
                if (flag)
                {
                    openedFpsUnlock.Kill();
                }
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Process.Start("AutoClicker");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Process.Start("Multiple_ROBLOX");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Process.Start("TinyTask");
        }

        private void TopMostRadio_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
