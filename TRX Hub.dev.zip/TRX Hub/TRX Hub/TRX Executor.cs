﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeAreDevs_API;
using EasyExploits;
using System.Diagnostics;
using System.IO;

namespace TRX_Hub
{
    public partial class TRX_Executor : Form
    {
        public TRX_Executor()
        {
            InitializeComponent();
        }
        Point lastPoint;
        ExploitAPI API = new ExploitAPI();
        EasyExploits.Module EasyExploitsAPI = new EasyExploits.Module();
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Process[] roblox = Process.GetProcesses();
            foreach (Process openedroblox in roblox)
            {
                bool flag = openedroblox.ProcessName == "RobloxPlayerBeta";
                if (flag)
                {
                    openedroblox.Kill();
                }
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            fastColoredTextBox1.Text = File.ReadAllText($"./Scripts/{listBox1.SelectedItem}");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();//Clear Items in the LuaScriptList
            Functions.PopulateListBox(listBox1, "./Scripts", "*.txt");
            Functions.PopulateListBox(listBox1, "./Scripts", "*.lua");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (EasyExploitsRadio.Checked == true)
            {
                EasyExploitsAPI.ExecuteScript(fastColoredTextBox1.Text);
            }

            else if (WeAreDevsRadio.Checked == true)
            {
                API.SendLuaScript(fastColoredTextBox1.Text);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (EasyExploitsRadio.Checked == true)
            {
                EasyExploitsAPI.LaunchExploit();
            }

            else if (WeAreDevsRadio.Checked == true)
            {
                API.LaunchExploit();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            _ = System.Diagnostics.Process.Start("https://discord.gg/VkyYHWBYsf");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Clear();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }

        private void fastColoredTextBox1_Load(object sender, EventArgs e)
        {
            
        }

        private void TRX_Executor_Load(object sender, EventArgs e)
        {
            listBox1.Items.Clear();//Clear Items in the LuaScriptList
            Functions.PopulateListBox(listBox1, "./Scripts", "*.txt");
            Functions.PopulateListBox(listBox1, "./Scripts", "*.lua");
            fastColoredTextBox1.Language = FastColoredTextBoxNS.Language.Lua;
        }
    }
}
