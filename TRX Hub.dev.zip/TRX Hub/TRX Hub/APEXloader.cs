﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TRX_Hub
{
    public partial class APEXloader : Form
    {
        public APEXloader()
        {
            InitializeComponent();
        }
        Point lastPoint;
        private void timer1_Tick(object sender, EventArgs e)
        {
            panel2.Width += 3;
            if (panel2.Width >= 277)
            {
                timer1.Stop();
                this.Hide();
                TRX_Executor_APEX form = new TRX_Executor_APEX();
                form.Show();
            }
        }

        private void APEXloader_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void APEXloader_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void APEXloader_Load(object sender, EventArgs e)
        {

        }
    }
}
